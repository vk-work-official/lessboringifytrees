const Text = {
    variants: {
        'emphysis': {
            fontStyle: 'normal',
            fontSize: '1rem',
            fontWeight: '700',
            lineHeight: '18px',
        },
        'variex-ff': {
            fontFamily: `'Variex', sans-serif`,
            fontSize: '2.875rem',
        }
    }
}

export default Text;